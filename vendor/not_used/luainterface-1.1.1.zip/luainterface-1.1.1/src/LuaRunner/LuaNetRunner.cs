using System;
using LuaInterface;

/*
 * Application to run Lua scripts that can use LuaInterface
 * from the console
 * 
 * Author: Fabio Mascarenhas
 * Version: 1.0
 */
namespace LuaRunner
{
	public class LuaNetRunner
	{
		/*
		 * Runs the Lua script passed as the first command-line argument.
		 * It passed all the command-line arguments to the script.
		 */
		public static void Main(string[] args) 
		{
			if(args[0]!="") 
			{
				Lua lua=new Lua();
				lua.OpenBaseLib();
				lua.OpenIOLib();
				lua.OpenStringLib();
				lua.OpenMathLib();
				lua.OpenTableLib();
				lua.OpenDebugLib();
				lua.NewTable("arg");
				LuaTable argc=(LuaTable)lua["arg"];
				argc[-1]="LuaRunner";
				argc[0]=args[0];
				for(int i=1;i<args.Length;i++) 
				{
					argc[i]=args[i];
				}
				argc["n"]=args.Length-1;
				lua.DoFile(args[0]);
			} 
			else 
			{
				Console.WriteLine("LuaRunner -- runs Lua scripts with CLR access");
				Console.WriteLine("Usage: luarunner <script.lua> [{<arg>}]");
			}
		}
	}
}

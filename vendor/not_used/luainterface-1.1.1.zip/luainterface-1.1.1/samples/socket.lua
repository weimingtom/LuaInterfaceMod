load_assembly("mscorlib")
load_assembly("System")

WebClient=import_type("System.Net.WebClient")
StreamReader=import_type("System.IO.StreamReader")
Math=import_type("System.Math")

print(Math:Pow(2,3))

myWebClient = WebClient()
myStream = myWebClient:OpenRead(arg[1])
sr = StreamReader(myStream)
line=sr:ReadLine()
repeat
  print(line)
  line=sr:ReadLine()
until not line
myStream:Close()

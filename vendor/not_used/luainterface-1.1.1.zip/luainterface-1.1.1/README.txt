LuaInterface 1.0
----------------

Copyright � 2003 Fabio Mascarenhas de Queiroz

lua-5.0.dll e lualib-5.0.dll are
Copyright � 2003 Tecgraf, PUC-Rio

Instructions for installing and using in the doc/guide.pdf file.



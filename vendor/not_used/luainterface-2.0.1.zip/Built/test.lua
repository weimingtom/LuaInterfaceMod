width=100
height=200
message="Hello World!"
color={r=100,g=20,b=50}
tree={branch1={leaf1=10,leaf2="leaf2"},leaf3="leaf3"}

function func(x,y)
  return x,x+y
end


Some example scripts, showing what LuaInterface can do.

form		A simple form, basic event handling
socket		Fetches the content of a web site and prints to the
		console
testluaform	A more complex WinForms example, type some Lua code in
		the textbox and run it, or load a Lua script.
